package circularll;

public class CollectionUtils {

}
